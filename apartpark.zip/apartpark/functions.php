<?php
define('THEME_VERSION', '1.0.3');
// Constants
define( 'THEME_DIR', get_template_directory() );
define( 'THEME_URI', get_template_directory_uri() );
// Javascript and CSS Paths.
define( 'CSS_DIR_URI', THEME_URI . '/assets/css/' );
define( 'JS_DIR_URI', THEME_URI . '/assets/js/' );

// Enable THUMBNAILS for all posts/sliders/pages
add_theme_support( 'post-thumbnails' );




/**
 * Display a widget "Hello!" to the admin dashboard.
 */
function apk_add_dashboard_widgets() {
    wp_add_dashboard_widget(
        'apk_dashboard_widget',                                      // Widget slug.
        esc_html__( 'Motyw ApartPark - zadanie testowe', 'apk' ),    // Title.
        'apk_dashboard_widget_render'                                // Display function.
    ); 
}
add_action( 'wp_dashboard_setup', 'apk_add_dashboard_widgets' );
 
function apk_dashboard_widget_render() {
    esc_html_e( "Motyw edytowalny: logo, menu, tło nagłówka, social media, slider z podziałem na kategorie + tagi (ostatnie 9 wpisów, sortowanie malejąco wg daty), content, wpisy, stopka (logo, firma, adres, copyright)", "apk" );
}
/********************************************************************************************/


/**
 * Add scripts and styles to header
 */
function apk_AddThemeScripts() {

    // Main CSS
    wp_enqueue_style('setting',  CSS_DIR_URI .'setting.css', false, THEME_VERSION);
    wp_enqueue_style('style',    CSS_DIR_URI .'style.css', 'setting', THEME_VERSION);
    wp_enqueue_style('glider',   CSS_DIR_URI .'glider.css','setting', THEME_VERSION);
    
    // Calendar jQueryUI CSS:
    wp_enqueue_style( 'calendar', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css');

    wp_enqueue_script('jQuery', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js');
    wp_enqueue_script('widget', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js', 'jQuery');
    wp_enqueue_script('lang', JS_DIR_URI .'polish.js', 'jQuery');
    //Page JS
    wp_enqueue_script('tools', JS_DIR_URI .'tools.js', 'jQuery', THEME_VERSION, true);

    //FrontPage  => Slider Glider ON 
    if (is_front_page() || is_home() ) {
        wp_enqueue_script('glider', JS_DIR_URI .'glider.min.js', false, true);
        wp_enqueue_script('set-glider', JS_DIR_URI .'glider-setting.js', 'glider', THEME_VERSION, true);
    }
}
add_action( 'wp_enqueue_scripts', 'apk_AddThemeScripts' );


/**
 * Logo Setup or Default Logo :
 */

function apk_custom_logo_setup() {
    $defaults = array(
        'height'               => 100,
        'width'                => 60,
        'flex-height'          => true,
        'flex-width'           => true,
    );
 
    add_theme_support( 'custom-logo', $defaults );
}
 
add_action( 'after_setup_theme', 'apk_custom_logo_setup' );



$bg_option = array(
    'wp-head-callback' => 'background_section',
    'default-color' => '0b1c44',
    'default-image' => THEME_URI . '/assets/img/bg-photo.png',
);
add_theme_support('custom-background', $bg_option);

function background_section() {
    ob_start();

    if ( is_front_page() && is_home() )
    {
        _custom_background_cb(); // Default handler
    }
    

    $style = ob_get_clean();
    $style = str_replace( 'body.custom-background', '#home-image', $style );

    echo $style;
}


/********************************************
 * Calendar Form Header with Today + 4 day
 *******************************************/
function apk_registration_form() {
	?>
<input type="text" name="from" value="<?php echo date('d.m', strtotime("+1 day"));?>" class="datepicker">
<img src="<?php echo get_template_directory_uri(); ?>/assets/img/arrow_right.png" alt="" />
<input type="text" name="to" value="<?php echo date('d.m', strtotime("+4 day"));?>" class="datepicker" id="alternate">
<?php
}
add_action( 'register_form', 'apk_registration_form' );


/********************************************
 * Add nav Menu, Mobile and Footer Bar Menu:
 *******************************************/
function add_nav_menus() {
    register_nav_menus( array(
        'desktop-menu'     => 'Header Menu - desktop screen',
        'footer-left'      => 'Footer Menu - left bar',
        'footer-center'    => 'Footer Menu - center bar',
        'mobile-menu'      => 'Mobile Menu - sticky footer'
    ));
}
add_action('init', 'add_nav_menus');


/**
 * Add 'class' to Nav <li class="...."> in Menu
 */
function add_nav_li_class( $classes, $item, $args ) {
    if (property_exists($args, 'li_class')) {
        $classes[] = $args->li_class;
    }
    return $classes;
  }
add_filter('nav_menu_css_class', 'add_nav_li_class', 1, 3);

/**
 * Add 'class' to Nav <a class="...."> in Menu
 */
function add_nav_link_class( $atts, $item, $args ) {
    if (property_exists($args, 'link_class')) {
      $atts['class'] = $args->link_class;
    }
    return $atts;
  }
add_filter( 'nav_menu_link_attributes', 'add_nav_link_class', 1, 3 );

/**
 * Add Header, Slider Intro and Footer sections: 1. Section, 2. Setting, 3. Contol
 */
function apk_header_footer_text($wp_customize) {
    
    // Header section
    $wp_customize->add_section('apk-header-section', array(
        'title' => __( 'Header' ),
        'description' => __( 'Theme Modifications: header text in front page ')
        )
    );
    // Slider section
    $wp_customize->add_section('apk-slider-section', array(
        'title' => __( 'Slider Intro' ),
        'description' => __( 'Slider Modifications Text in front page')
        )
    );
    // Footer section
    $wp_customize->add_section('apk-footer-section', array(
        'title' => __( 'Footer' ),
        'description' => __( 'Footer Modifications Company')
        )
    );
    
    /******* Head *******/
    // Booking tagline before button 
    $wp_customize->add_setting('apk-tagline-button-before', array(
        'default' => 'Example text about price!',
            ) );
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-tagline-button-before-control', array(
        'label' => 'Booking Tagline',
        'section' => 'apk-header-section',      // 'Header' section
        'settings' => 'apk-tagline-button-before')
    ));

    // Button Text
    $wp_customize->add_setting('apk-tagline-button', array(
        'default' => __('Booking online')
            ) );
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-tagline-button-control', array(
        'label' => 'Booking Button Text',
        'section' => 'apk-header-section',      // 'Header' section
        'settings' => 'apk-tagline-button')
    ));
    
    // Before H1 - strapline
    $wp_customize->add_setting('apk-header-headline-before', array(
        'default' => 'Example text before H1',
            ) );
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-header-headline-before-control', array(
        'label' => '-- Strapline Text --',
        'section' => 'apk-header-section',      // 'Header' section
        'settings' => 'apk-header-headline-before')
    ));

    // Headline
    $wp_customize->add_setting('apk-header-headline', array(
        'default' => 'Example headline main text H1',
        ) );        
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-header-headline-control', array(
        'label' => 'Headline Text',
        'section' => 'apk-header-section',      // 'Header' section
        'settings' => 'apk-header-headline')
    ));

    // Link Text 
    $wp_customize->add_setting('apk-header-link-text', array(
        'default' => 'Example Text Link',
        ) );        
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-header-link-text-control', array(
        'label' => 'Text Link',
        'section' => 'apk-header-section',      // 'Header' section
        'settings' => 'apk-header-link-text')
    ));

    
    /******* Slider *******/
    // Slider Name 
    $wp_customize->add_setting('apk-slider-name', array(
        'default' => 'Example Name',
        ) );        
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-slider-name-control', array(
        'label' => 'Name--',
        'section' => 'apk-slider-section',      // 'Slider' section
        'settings' => 'apk-slider-name')
    ));

    // Slider Title 
    $wp_customize->add_setting('apk-slider-title', array(
        'default' => 'Example Title - ApartPark',
        ) );        
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-slider-title-control', array(
        'label' => 'Title',
        'section' => 'apk-slider-section',      // 'Slider' section
        'settings' => 'apk-slider-title')
    ));
    
    // Slider Text 
    $wp_customize->add_setting('apk-slider-text', array(
        'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book',
        ) );        
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-slider-text-control', array(
        'label' => 'Text',
        'type' => 'textarea',
        'description' => __( 'This is a custom textarea' ),
        'section' => 'apk-slider-section',      // 'Slider' section
        'settings' => 'apk-slider-text')
    ));

    /******* Footer *******/
    // Company Name 
    $wp_customize->add_setting('apk-company-title', array(
        'default' => 'Example ApartPark Home S.C',
        ) );        
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-company-title-control', array(
        'label' => 'Company',
        'section' => 'apk-footer-section',      // 'Footer' section
        'settings' => 'apk-company-title')
    ));
    // Company Adress 
    $wp_customize->add_setting('apk-company-adress', array(
        'default' => 'Example ul. Uzdrowiskowa 48, 72-600 City',
        ) );        
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-company-adress-control', array(
        'label' => 'Address',
        'section' => 'apk-footer-section',      // 'Footer' section
        'settings' => 'apk-company-adress')
    ));
    // Copyright 
    $wp_customize->add_setting('apk-copyright', array(
        'default' => '2022 © Made with love Example',
        ) );        
    $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'apk-copyright-control', array(
        'label' => 'Copyright  ©',
        'section' => 'apk-footer-section',      // 'Footer' section
        'settings' => 'apk-copyright')
    ));
    
}
add_action( 'customize_register', 'apk_header_footer_text' );


/**
 * Add Social Media Icon = > Header, Footer, Mobile Menu
 */

function social_widgets_init() {
	register_sidebar(
        array(
			'name'          => esc_html__( 'Insert Social Icons Block', 'apartpark' ),
			'id'            => 'social',
			'description'   => __( 'To add the <strong>Social Icons block</strong>, click on the <strong>+ Block Inserter</strong> icon and search for “<i>social icons</i>”', 'apartpark' ),
			'before_widget' => '<section class="widget-social">',
			'after_widget'  => '</section>'
		)
	);
}
add_action( 'widgets_init', 'social_widgets_init' );


/**
 * Register Slider Post Type => 'gallery'
 */
function add_slider_post() {
    
	$labels = array(
		'name'                  => 'Sliders',
		'singular_name'         => 'Slider',
		'menu_name'             => 'Slider/Gallery',
		'name_admin_bar'        => 'Slider',
		'archives'              => 'Archives',
		'attributes'            => 'Attributes',
		'parent_item_colon'     => 'Parent:',
		'all_items'             => 'All Sliders',
		'add_new_item'          => 'Add New',
		'add_new'               => 'Add New',
		'new_item'              => 'New Slider',
		'edit_item'             => 'Edit Slider',
		'update_item'           => 'Update Slider',
		'search_items'          => 'Search',
		'not_found'             => 'Not found',
		'not_found_in_trash'    => 'Not found in Trash',
		'featured_image'        => 'Slider Image',
		'set_featured_image'    => 'Set featured image',
		'remove_featured_image' => 'Remove featured image',
		'use_featured_image'    => 'Use as featured image',
		'insert_into_item'      => 'Insert into item',
		'uploaded_to_this_item' => 'Uploaded to this item',
		'items_list'            => 'Items list',
		'items_list_navigation' => 'Items list navigation',
		'filter_items_list'     => 'Filter items list',
	);
	$args = array(
		'label'                 => 'Slider',
		'description'           => 'Insert Carousel photo in to FrontPage',
		'labels'                => $labels,
		'supports'              => array( 'title', 'excerpt', 'editor', 'thumbnail' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 20,
		'menu_icon'             => 'dashicons-images-alt2',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => false,
		'can_export'            => false,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page'
	);
	register_post_type( 'gallery', $args );  // 'gallery' => post type 
     
}
add_action( 'init', 'add_slider_post', 0 );


/**
 * Generate breadcrumbs
 */
function get_breadcrumb() {
    echo '<ul>';
    echo '<li>Start</li>';
    if (is_category() || is_single()) {
        
        the_category(' &bull; ');
            if (is_single()) {
                echo "<li>";
                the_title();
                echo "</li>";
            }
    } elseif (is_page()) {
        echo "<li>";
        echo the_title();
        echo "</li>";
    }
    echo '</ul>';
}


?>