<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php the_title(); ?></title>
    <?php wp_head(); ?>
</head>

<body>
    <section class="container <?php echo (is_front_page() && is_home()) ? "bg-photo" : "navy-bg" ?>" id="home-image">

        <header class=" border flex space">

            <div class="flex align-end">
                <div class="logo">
                    <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                    <?php else: ?>
                    <a href="<?php echo home_url(); ?>"><img
                            src="<?php echo get_template_directory_uri(); ?>/assets/img/logo-apartpark.png"
                            alt="Logo" /></a>
                    <?php endif; ?>
                </div>
                <?php
                    wp_nav_menu( array(
                    'theme_location'    => 'desktop-menu',
                    'container'         => 'nav',
                    'container_class'   => 'navbar',
                    'menu_class'        => 'nav-menu',
                    'li_class'          => 'nav-item',
                    'link_class'        => 'nav-link'                         
                    ));
                ?>
            </div>

            <div class="calendar flex align-end">

                <div class="frameBox">
                    <?php apk_registration_form() ?>
                </div>
                <div class="submit">
                    <h6><?php echo get_theme_mod('apk-tagline-button-before', __('Example text')) ?></h6>
                    <button type="submit"
                        class="btn btn-white"><?php echo get_theme_mod('apk-tagline-button', __('Example text')) ?></button>
                </div>

                <ul class="lang">
                    <li class="drop"><a class="icon" href="#">pl</a>
                        <ul class="dropdown">
                            <li><a href="#">en</a></li>
                            <li><a href="#">de</a></li>
                        </ul>
                    </li>
                </ul>

            </div>
        </header>

        <?php if ( is_front_page() && is_home() ) : ?>

        <div class="header--topic">
            <h4><?php echo get_theme_mod('apk-header-headline-before', __('Example text')) ?></h4>
            <h1><?php echo get_theme_mod('apk-header-headline', __('Example text')) ?></h1>
        </div>

        <div class="circle">
            <div class="circle--ring"></div>
            <div class="circle--link">
                <a href="#"><?php echo get_theme_mod('apk-header-link-text', __('Example text')) ?></a>
            </div>
        </div>

        <!-- Social Media Icon block -->
        <div class="header--topic-social flex">
            <?php get_sidebar();?>
        </div>
        <?php else: ?>
        <div class="text-center header--topic">
            <h1><?php wp_title(''); ?></h1>
            <nav class="breadcrumb">
                <?php get_breadcrumb() ?>
            </nav>
        </div>
        <?php endif ?>
    </section>