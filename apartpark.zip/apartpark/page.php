<?php get_header(); ?>

<main class="container gradient">
    <section class="home">
        <?php the_content(); ?>
    </section>
</main>


<?php get_footer(); ?>