<?php if (is_active_sidebar('social') ) : 
    dynamic_sidebar('social'); //
else : 
// Default Social Icon from template
?>
<div class="social">
    <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/facebook.png" alt="FB" /></a>
</div>
<div class="social">
    <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/instagram.png" alt="Instagram" /></a>
</div>
<div class="social">
    <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/ytb.png" alt="YT" /></a>
</div>
<?php endif ?>