<?php 
    // Social Media Icon <sidebar-social.php>
    get_sidebar( 'social' );

    // Insert multi sidebar: <?php include( TEMPLATEPATH . '/sidebar-social.php'); - in to template
?>