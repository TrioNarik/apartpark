        <section class="flex space discovery">
            <article class="col30">
                <h5>Komfortowy wypoczynek</h5>
                <h2>Odkryj Apartpark</h2>
                <p>Zobacz apartamenty w pierwszej linii nadmorskiej zabudowy. Każdy z nich przygotowaliśmy z myślą o
                    Twoich wakacjach. Dlatego oferujemy również wyżywienie na miejscu oraz usługę hotelową w
                    standardzie</p>
                <div class="more">
                    <a href="strona.html">o nas</a>
                </div>
            </article>
            <aside>
                <div class="discovery--photo">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hotel_homepage.png" alt="Hotel" />
                </div>
                <div class="discovery--video">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/video_homepage.png" alt="Video" />
                    <div class="discovery--video__link">
                        <a href="#">Zobacz film</a>
                    </div>
                </div>
            </aside>
        </section>


        <section class="flex space content">
            <article class="col30">
                <h3>Doskonała lokalizacja</h3>
                <p>Szum fal i odgłosy mew na rozgrzanej słońcem plaży to Twoje wymarzone wakacje. Aby były idealne,
                    potrzebujesz tylko luksusowego apartamentu, położonego nad samym morzem. Dokładnie: 300 metrów
                    od plaży.</p>
            </article>
            <article class="col30">
                <h3>Pełny komfort</h3>
                <p>Wśród 370 apartamentów znajdziesz swój wymarzony z przestronną sypialnią i w pełni wyposażonym
                    aneksem kuchennym. Zapraszamy do strefy relaksu na terenie obiektu oraz naszej wyjątkowej
                    restauracji Sofa Cafe i polecanej restauracji Sofa Bistro.</p>
            </article>
            <article class="col30">
                <h3>Idealne wakacje</h3>
                <p>Czekają na Ciebie czysta plaża w Świnoujściu oraz wiele innych atrakcji: od interesujących
                    obiektów historycznych po możliwość uprawiania sportów ekstremalnych. A wszystko to tuż nad
                    polskim morzem.</p>
            </article>

        </section>