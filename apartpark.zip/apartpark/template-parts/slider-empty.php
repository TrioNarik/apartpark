<?php 
$i = 1;
while ( $i <= 3 ) {
?>
<div class="glider-slide">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slider<?php echo $i;?>.png" />
    <div class="pad-2">
        <h3>Apartament Rubus 401</h3>
        <p>2 osoby / 1 sypialnia / 40 m2</p>
        <small>*Śniadanie wliczone w cenę</small>
        <p><a href="strona.html">Zobacz apartament</a></p>
    </div>
</div>
<?php 
$i++;}
?>