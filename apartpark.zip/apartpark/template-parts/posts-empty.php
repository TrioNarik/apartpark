<section class="container posts">
    <div class="page">
        <h5>Atrakcje Świnoujścia</h5>
        <h2>Inspiracje dla Ciebie</h2>
        <p class="col50">Poznaj najlepsze atrakcje Świnoujścia i okolic. Dowiedz się, jak aktywnie spędzać wakacje
            nad morzem. Zobacz miejsca, które warto odwiedzić. Sprawdź, jak urozmaicić wypoczynek dzieciom.
            Zainspiruj się!</p>

        <div class="more">
            <a href="strona.html">Wszystkie artykuły</a>
        </div>

        <div class="flex space">
            <article class="col32">
                <div class="posts--img">
                    <img src="img/article1.jpg" />
                    <div class="posts--link">
                        <a href="#"><img src="img/button_arrow.png" /></a>
                    </div>
                </div>
                <div class="article--date">
                    <p><time datetime="2022-02-21 19:00">21/02/2022</time></p>
                </div>
                <p>Pierwsza linia zabudowy, czyli niecałe 300m - zaledwie tyle dzieli Cię od wypoczynku na naszej
                    prywatnej plaży [...] <a href="#">Czytaj więcej</a></p>
            </article>
            <article class="col32">
                <div class="posts--img">
                    <img src="img/article2.jpg" />
                    <div class="posts--link">
                        <a href="#"><img src="img/button_arrow.png" /></a>
                    </div>
                </div>
                <div class="article--date">
                    <p><time datetime="2022-02-21 19:00">21/02/2022</time></p>
                </div>
                <p>Pierwsza linia zabudowy, czyli niecałe 300m - zaledwie tyle dzieli Cię od wypoczynku na naszej
                    prywatnej plaży [...] <a href="#">Czytaj więcej</a></p>
            </article>
            <article class="col32">
                <div class="posts--img">
                    <img src="img/article3.jpg" />
                    <div class="posts--link">
                        <a href="#"><img src="img/button_arrow.png" /></a>
                    </div>
                </div>
                <div class="article--date">
                    <p><time datetime="2022-02-21 19:00">21/02/2022</time></p>
                </div>
                <p>Pierwsza linia zabudowy, czyli niecałe 300m - zaledwie tyle dzieli Cię od wypoczynku na naszej
                    prywatnej plaży [...] <a href="#">Czytaj więcej</a></p>
            </article>
        </div>
    </div>
</section>