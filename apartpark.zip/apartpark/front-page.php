<?php get_header(); ?>

<main class="container gradient">

    <div class="page">
        <?php get_template_part('template-parts/front','empty');?>
    </div>

</main>


<section class="container navy-bg">
    <div class="page">
        <h5><?php echo get_theme_mod('apk-slider-name', __('Example text')) ?></h5>
        <h2><?php echo get_theme_mod('apk-slider-title', __('Example text')) ?></h2>
        <p class="col50"><?php echo get_theme_mod('apk-slider-text', __('Example text')) ?></p>
    </div>
</section>
<section class="navy-bg slider">
    <div class="glider-contain">
        <div class="glider flex">

            <?php
query_posts(array(
    'post_type' => 'gallery',
    'posts_per_page' => 9,
    'order'       => 'DESC',
    'orderby'     => 'date'));
    
    if (have_posts()) :
        while (have_posts()) : the_post();
            ?>
            <div class="glider-slide">

                <?php the_post_thumbnail(); ?>
                <div><?php echo category_description();?></div>
                <div class="pad-2">

                    <h3><?php the_title(); ?></h3>

                    <p><?php the_tags('', ' / ', ''); ?></p>
                    <small><?php the_excerpt();?></small>
                    <p><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
                </div>
            </div>
            <?php
    endwhile;
else : 
    get_template_part('template-parts/slider','empty');
endif;
?>
        </div>
        <button aria-label="Next" class="glider-next"></button>
        <button aria-label="Previous" class="glider-prev"></button>
        <div role="tablist" class="dots"></div>
    </div>
</section>
<section class="container navy-bg">
    <div class="page-slider">
        <div class="more">
            <a href="strona.html">Wszystkie apartamenty</a>
        </div>
    </div>
</section>

<section class="container posts">
    <div class="page">
        <?php get_template_part('template-parts/content','empty');?>
    </div>
</section>

<?php get_footer(); ?>