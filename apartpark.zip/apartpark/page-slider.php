<?php get_header(); ?>
<?php 
    $slug = get_post_field( 'post_name', get_post() );
    $slug = ( locate_template( 'page' . $slug . '.php' ) ) ? $slug : 'default';

    get_template_part( 'page' . $slug  );
?>

<?php get_footer(); ?>