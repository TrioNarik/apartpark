$(function () {
	// Calendar
	$(".datepicker").datepicker({
		dateFormat: "dd.mm",
		altField: "#alternate",
		altFormat: "dd.mm",
	});

	// Dropdown section hover Lang
	$(".drop").hover(function () {
		$("ul.dropdown").toggleClass("visible");
	});

	// Drop Menu Mobile
	$(".dropUp").click(function () {
		$(".dropdown--menu-mobile").toggleClass("show");
	});

	// Cookies
	$("#hide").click(function () {
		$(".cookies").slideToggle();
	});
});
