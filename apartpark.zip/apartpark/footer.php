<footer class="container bg-footer">
    <section class="footer">
        <div class="logo hiding center">
            <?php if (has_custom_logo()) : 
             the_custom_logo(); 
            else: ?>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo-apartpark.png" alt="Logo" />
            <?php endif; ?>
        </div>
        <div class="footer--topic">
            <h2><?php echo get_theme_mod('apk-company-title', __('Example text')) ?></h2>
            <p><?php echo get_theme_mod('apk-company-adress', __('Example text')) ?></p>
        </div>
        <div class="hiding flex center">
            <?php include( TEMPLATEPATH . '/sidebar-social.php'); ?>
        </div>

        <div class="flex space border-top">
            <div class="col30">
                <?php if (wp_get_nav_menu_name( 'footer-left' ) ) :
					echo '<h3 class="hide-mobile">'.wp_get_nav_menu_name( 'footer-left' ).'</h3>';
                 		wp_nav_menu( array(
                    		'theme_location'    => 'footer-left'                       
                    	)); // 
                else : ?>
                <h3 class="hide-mobile">Odkryj Apartpark</h3>
                <ul>
                    <li><a href="#">Poznaj Apartpark</a></li>
                    <li><a href="#">Znajdź apartament</a></li>
                    <li><a href="#">Zarezerwuj pobyt</a></li>
                    <li><a href="#">Sofa Bistro</a></li>
                    <li><a href="#">Sofa Cafe</a></li>
                </ul>
                <?php endif ?>
            </div>
            <div class="col30">
                <?php if (wp_get_nav_menu_name( 'footer-center' ) ) :
					echo '<h3 class="hide-mobile">'.wp_get_nav_menu_name( 'footer-center' ).'</h3>';
                 		wp_nav_menu( array(
                    		'theme_location'    => 'footer-center'                       
                    	)); // 
                else : ?>
                <h3 class="hide-mobile">Odkryj Apartpark</h3>
                <ul>
                    <li><a href="#">Atrakcje</a></li>
                    <li><a href="#">Współpraca</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Kontakt</a></li>
                </ul>
                <?php endif ?>


            </div>
            <div id="full" class="col30">
                <h3>Czekamy na Ciebie</h3>
                <input type="text" name="name" placeholder="Imię i nazwisko">
                <input type="text" name="email" placeholder="Adres e-mail lub nr telefonu">
                <textarea name="message" placeholder="Wiadomość" rows="4"></textarea>
                <button type="submit" class="btn">wyślij wiadomość</button>
            </div>

        </div>

        <div class="border-top" id="empty">
            <div class="flex space">
                <div class="hide-mobile flex">
                    <?php include( TEMPLATEPATH . '/sidebar-social.php'); ?>
                </div>
                <div class="copyright">
                    <?php echo get_theme_mod('apk-copyright') ?>
                </div>
            </div>

        </div>

    </section>


</footer>

<!--- MENU MOBILE -->
<nav class="navbar-mobile">
    <ul class="mobile flex space">
        <li class="icon"><a href="#"><span>Kontakt</span><span><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_phone.png"
                        alt="EN" /></span></a>
        </li>
        <li class="icon booking"><a href="#"><span>Rezerwuj</span><span><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_booking.png"
                        alt="EN" /></span></a></li>
        <li class="icon dropUp"><a href="javascript:void(0)"><span>Menu</span><span><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_menu_close.png" alt="EN" /></a>
            <div class="dropdown--menu-mobile">
                <ul class="lang-mobile flex start">
                    <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/flag_pl.png"
                                alt="PL" /></a>
                    <li class="social"><a href="#"><img
                                src="<?php echo get_template_directory_uri(); ?>/assets/img/flag_en.png" alt="EN" /></a>
                    </li>
                    <li class="social"><a href="#"><img
                                src="<?php echo get_template_directory_uri(); ?>/assets/img/flag_de.png" alt="DE" /></a>
                    </li>
                </ul>
                <ul class="nav-menu-mobile">
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Poznaj Apartpark</a></li>
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Znajdź apartament</a></li>
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Zarezerwuj pobyt</a></li>
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Sofa Bistro</a></li>
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Sofa Cafe</a></li>
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Atrakcje</a></li>
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Współpraca</a></li>
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Blog</a></li>
                    <li class="nav-item-mobile"><a href="strona.html" class="nav-link">Kontakt</a></li>
                </ul>
                <?php include( TEMPLATEPATH . '/sidebar-social.php'); ?>
            </div>
        </li>
    </ul>
</nav>

<div class="cookies">Ta strona używa plików cookies. Aby dowiedzieć się więcej zobacz naszą Politykę Prywatności.
    <a id="hide" href="javascript:void(0)">&#10006;</a>
</div>
<?php wp_footer(); ?>
</body>

</html>